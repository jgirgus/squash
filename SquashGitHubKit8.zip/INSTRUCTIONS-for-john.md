# Squash 1.4 on GitHub — the two jobs

This kit updates the page for the new app (one Radio scheme, no
modes, the over-squash protections, Version 1.4). Your headline
and your footer are untouched. There are two jobs; do the
release first so the page never promises what the Download
button doesn't deliver yet.

## Job 1 — publish the new app (the release)

Use the **Squash.zip you made from the Any Mac build of v19**
(Get Info on the app said Version 1.4, Universal).

1. Go to **github.com/jgirgus/squash** → **Releases** →
   **Draft a new release**.
2. Tag: type **v1.4** and let it create the tag. Title:
   **Squash 1.4**.
3. Drag your **Squash.zip** into the attachments box. The name
   must be exactly `Squash.zip` — the page's Download button
   looks for that name on the newest release.
4. Click **Publish release**.

Done. The Download button now serves 1.4 automatically — it
always points at the latest release. The old 1.1 release can
stay; it just stops being "latest".

## Job 2 — update the page (one upload, one commit)

Inside this kit's **Squash site files** folder are seven files:

- `index.html` — the page (Version 1.4, no modes, new wording)
- `README.md` — the repo front page, same update
- `og-image.png` — the social card (unchanged, still accurate)
- `squash-icon.png` — the icon (unchanged)
- `shot-gentle.png`, `shot-radio.png`, `shot-full.png` — the
  app at 25 / 50 / 90%, drawn from the current window

1. Unzip this kit and open the **Squash site files** folder.
2. In the repo: **Add file → Upload files**.
3. Drag in **all seven files** and click **Commit changes**.
   Four replace old files; the three screenshots are new.
4. Optional tidy-up: the old `shot-light-touch.png`,
   `shot-radio-limit.png` and `shot-max-squash.png` are no
   longer used by the page. You can delete each from the
   repo's file list whenever you feel like it — leaving them
   hurts nothing.

You do **not** need to redo the Pages setting. To see the new
page without your browser's cache getting in the way, open
**jgirgus.github.io/squash/?new**.

Tell Muse when both jobs are done and it will download the
release from the public page and verify it's really the 1.4
universal build inside.
